document.addEventListener('DOMContentLoaded', () => {
    // Verificación de sesión
    if (!sessionStorage.getItem('loggedIn')) {
        window.location.href = 'login.html';
        return;
    }

    const username = sessionStorage.getItem('username');
    const numerosContainer = document.getElementById('numeros');
    const numeroSeleccionado = document.getElementById('numeroSeleccionado');
    const venderBtn = document.getElementById('venderBtn');
    const totalVentas = document.getElementById('totalVentas');
    const premio = document.getElementById('premio');
    const logoutBtn = document.getElementById('logoutBtn');
    const ciclosCompletosElem = document.getElementById('ciclosCompletos');

    const userPrefix = `user_${username}_`;
    const vendidosKey = `${userPrefix}vendidos`;
    const ventasKey = `${userPrefix}ventas`;
    const ciclosCompletosKey = `${userPrefix}ciclosCompletos`;

    let vendidos = JSON.parse(localStorage.getItem(vendidosKey)) || [];
    let ventas = parseInt(localStorage.getItem(ventasKey)) || 0;
    let ciclosCompletos = parseInt(localStorage.getItem(ciclosCompletosKey)) || 0;
    const precioNumero = 100;
    const premioTotal = 900;
    let numeroActual = null;

    logoutBtn.addEventListener('click', () => {
        sessionStorage.removeItem('loggedIn');
        sessionStorage.removeItem('username');
        window.location.href = 'login.html';
    });

    function generarNumeros() {
        numerosContainer.innerHTML = '';
        for (let i = 1; i <= 10; i++) {
            let btn = document.createElement('button');
            btn.textContent = i;
            btn.disabled = vendidos.includes(i);
            btn.addEventListener('click', () => seleccionarNumero(i, btn));
            numerosContainer.appendChild(btn);
        }
    }

    function seleccionarNumero(numero, btn) {
        numeroActual = numero;
        numeroSeleccionado.textContent = `Número seleccionado: ${numero}`;
        venderBtn.disabled = false;
    }

    venderBtn.addEventListener('click', () => {
        if (numeroActual !== null && !vendidos.includes(numeroActual)) {
            vendidos.push(numeroActual);
            localStorage.setItem(vendidosKey, JSON.stringify(vendidos));
            const boton = Array.from(numerosContainer.children).find(btn => btn.textContent == numeroActual);
            if (boton) {
                boton.disabled = true;
            }
            numeroSeleccionado.textContent = 'Número seleccionado: Ninguno';
            venderBtn.disabled = true;
            ventas += precioNumero;
            localStorage.setItem(ventasKey, ventas);
            totalVentas.textContent = `Total de ventas: ${ventas} pesos`;
            imprimirTicket(numeroActual);

            if (vendidos.length >= 10) {
                reiniciarVentas();
            }
        } else {
            alert('Este número ya ha sido vendido.');
        }
    });

    function imprimirTicket(numero) {
        const ticketWindow = window.open('', '', 'width=300,height=400');
        ticketWindow.document.write(`
            <html>
                <head>
                    <title>Ticket de Rifa</title>
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            text-align: center;
                        }
                        h1 {
                            font-size: 24px;
                        }
                        p {
                            font-size: 18px;
                        }
                    </style>
                </head>
                <body>
                    <h1>Venta de Rifa</h1>
                    <p>Número vendido: ${numero}</p>
                    <p>Precio: ${precioNumero} pesos</p>
                </body>
            </html>
        `);
        ticketWindow.document.close();
        ticketWindow.print();
        ticketWindow.close();
    }

    function reiniciarVentas() {
        vendidos = [];
        ventas = 0;
        ciclosCompletos += 1;
        localStorage.setItem(ciclosCompletosKey, ciclosCompletos);
        localStorage.removeItem(vendidosKey);
        localStorage.removeItem(ventasKey);
        numeroActual = null;
        numeroSeleccionado.textContent = 'Número seleccionado: Ninguno';
        totalVentas.textContent = 'Total de ventas: 0 pesos';
        actualizarRegistroCiclos();
        generarNumeros();
    }

    function actualizarRegistroCiclos() {
        ciclosCompletosElem.textContent = `${ciclosCompletos} ciclos completos`;
    }

    totalVentas.textContent = `Total de ventas: ${ventas} pesos`;
    actualizarRegistroCiclos();
    generarNumeros();
});

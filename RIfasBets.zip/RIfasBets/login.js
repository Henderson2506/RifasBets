document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const loginError = document.getElementById('loginError');

    const users = [
        { username: 'admin', password: '123456' },
        { username: 'user1', password: '12345678' },
        { username: 'user2', password: '20242024' },
        { username: 'user3', password: 'password3' },
        { username: 'user4', password: 'password4' },
        { username: 'user5', password: 'password5' },
        { username: 'user6', password: 'password6' },
        { username: 'user7', password: 'password7' },
        { username: 'user8', password: 'password8' },
        { username: 'user9', password: 'password9' }
    ];

    loginForm.addEventListener('submit', (event) => {
        event.preventDefault();
        const username = event.target.username.value.trim();
        const password = event.target.password.value.trim();

        const user = users.find(user => user.username === username && user.password === password);

        if (user) {
            sessionStorage.setItem('loggedIn', 'true');
            sessionStorage.setItem('username', username);
            window.location.href = 'index.html'; // Redirige a la página principal si el login es exitoso
        } else {
            loginError.textContent = 'Usuario o contraseña incorrectos.';
        }
    });
});
